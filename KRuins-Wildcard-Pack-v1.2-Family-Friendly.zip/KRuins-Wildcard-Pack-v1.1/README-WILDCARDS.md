# KRuins Wildcard Pack v1.1 — Family-Friendly Edition

**Render Beyond Imagination** — Kinetic Ruins / Rampart

This edition is curated for an all-ages public release. All explicit ages are **21 or older**. Sexualized outfit descriptions have been replaced with general-purpose professional, athletic, or fantasy clothing. Some original entries were substantially revised or replaced.

## Installation
1. Extract the `Wildcards` folder to a convenient location.
2. In **KRuins Wildcard Batch**, set `wildcard_folder` to the full path of that folder.
3. Reference a file without `.txt`: `__haircolor__`, `__age__`, `__clothingcolor__`, etc.
4. To vary two characters independently, use `__haircolor__` and `__haircolor2__`, or `__hairstyle__` and `__hairstyle2__`.
5. Each nonempty line is one selection candidate. Nested references can point to another included file.

## Beginner example
`Photorealistic portrait of a __age__ person with __haircolor__ hair, __eyecolor__ eyes, wearing __clothingcolor__ clothing, in __lighting__.`

## Notes
- The pack is intended for public all-ages examples; it is not a universal guarantee of the output of any image model.
- Names and folder layout of original files are preserved. Added `haircolor2-4`, `hairstyle2-4`, and `clothingcolor2-4` for convenient independent selections.
- The original collection referenced wildcard folders not included in this archive. Where possible, references were normalized to included filenames or the incomplete entries were replaced.
- Use and redistribute subject to the accompanying license/terms chosen by the publisher.

## Public-release review (v1.1)
The wildcard entries were reviewed and remaining descriptions of very short garments, exposed chest panels, and overly body-focused outfits were replaced with practical alternatives. This pack contains adult age presets (21+). Clothing such as ordinary fitted tops or athletic swimwear is retained as standard non-explicit attire. Results produced by an image model may still vary.
