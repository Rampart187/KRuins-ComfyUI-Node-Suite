# KRuins PBC Pack Verification

- Wildcard TXT files checked: 51
- Files containing corrected nested references: 1
- Nested wildcard references unresolved: 0
- All detected nested wildcard references resolve to an existing TXT file in this pack.
